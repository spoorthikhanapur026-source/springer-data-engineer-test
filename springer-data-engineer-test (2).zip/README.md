# Springer Capital - Data Engineer Take-Home Test

## Setup
```
pip install -r requirements.txt
python your_script.py
```

## Docker
```
docker build -t referral-pipeline .
docker run -v $(pwd):/app referral-pipeline
```
