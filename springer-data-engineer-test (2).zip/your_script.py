import pandas as pd
import numpy as np

def load_data():
    tables = ['lead_logs', 'user_referrals', 'user_referral_logs', 'user_logs', 'user_referral_statuses', 'referral_rewards', 'paid_transactions']
    data = {}
    for table in tables:
        try:
            data[table] = pd.read_csv(f'data/{table}.csv')
        except FileNotFoundError:
            data[table] = pd.DataFrame()
    return data

def profile_data(data):
    profile_rows = []
    for name, df in data.items():
        for col in df.columns:
            profile_rows.append({'table': name, 'column': col, 'null_count': df[col].isnull().sum(), 'distinct_count': df[col].nunique()})
    pd.DataFrame(profile_rows).to_csv('profiling_results.csv', index=False)

def clean_and_merge(data):
    referrals = data['user_referrals']
    statuses = data['user_referral_statuses']
    rewards = data['referral_rewards']
    transactions = data['paid_transactions']
    users = data['user_logs']
    merged = referrals.merge(statuses, left_on='user_referral_status_id', right_on='id', how='left', suffixes=('', '_status'))
    merged = merged.merge(rewards, left_on='referral_reward_id', right_on='id', how='left', suffixes=('', '_reward'))
    merged = merged.merge(transactions, on='transaction_id', how='left', suffixes=('', '_txn'))
    merged = merged.merge(users, left_on='referrer_id', right_on='user_id', how='left', suffixes=('', '_referrer'))
    return merged

def apply_business_logic(df):
    def is_valid(row):
        try:
            if row['reward_value'] > 0 and row['description'] == 'Berhasil' and row['transaction_status'].upper() == 'PAID':
                return True
        except:
            return False
        return False
    df['is_business_logic_valid'] = df.apply(is_valid, axis=1)
    return df

def main():
    data = load_data()
    profile_data(data)
    merged = clean_and_merge(data)
    result = apply_business_logic(merged)
    result.to_csv('output_report.csv', index=False)

if __name__ == '__main__':
    main()
